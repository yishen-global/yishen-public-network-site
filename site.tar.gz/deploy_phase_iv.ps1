Set-ExecutionPolicy -Scope Process Bypass -Force
.\deploy_phase_iv.ps1
