﻿/* sovereign-ui.js - injected */
(function(){
  if (window.__SOV_UI__) return;
  window.__SOV_UI__ = true;

  // 你后续可以把“统一导航/统一logo/统一页脚”写成真正的 DOM 注入
  // 这里先做一个存在性标记，确保注入成功可验证：
  console.log("[SOVEREIGN_UI] injected OK:", location.pathname);
})();
